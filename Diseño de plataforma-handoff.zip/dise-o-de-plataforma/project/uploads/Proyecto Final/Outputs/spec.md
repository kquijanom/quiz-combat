# Spec: Plataforma de Duelos de Conocimiento (Fase 1)
Fecha: 13 de julio de 2026

## Overview
Plataforma de duelos de conocimiento asincrónicos para grupos cerrados (un curso, un grupo de amigos). Los miembros del grupo se retan entre sí a duelos 1v1 sobre un tema, respondiendo preguntas de opción múltiple tomadas de un banco precargado por el propio administrador del grupo. El objetivo es que estudiar o repasar se sienta más entretenido y conectado con el grupo, sin necesidad de coincidir en horario para jugar.

## Usuarios objetivo
- **Administrador del grupo**: crea el grupo, invita gente, y mantiene el banco de preguntas por tema. Hoy no tiene una forma fácil de convertir el material de estudio de su grupo en algo interactivo y competitivo.
- **Miembro del grupo**: se une con un link/código de invitación, elige temas y rivales, y juega duelos cuando tiene tiempo libre. Hoy estudia solo o repasa con métodos tradicionales (apuntes, quizzes estáticos) sin el factor social de competir contra alguien que conoce.

## Alcance

### La v1 SÍ hace
1. **Crear grupo y unirse por invitación**: el administrador crea un grupo y genera un código/link de invitación; cualquiera con ese código puede unirse y crear un perfil básico (nombre).
2. **Cargar banco de preguntas por tema**: el administrador sube un archivo con preguntas de opción múltiple organizadas por tema, para que los miembros puedan jugar duelos sobre esos temas.
3. **Jugar duelos asincrónicos 1v1**: un miembro elige un tema y un rival dentro del grupo, ambos responden el mismo set de preguntas cuando pueden (sin coincidir en horario).
4. **Ver el resultado final del duelo**: al completar ambos jugadores sus respuestas, se muestra quién ganó y el puntaje de cada uno.

### La v1 NO hace
- No genera preguntas con IA en el momento (las preguntas ya vienen cargadas por el administrador).
- No permite reportar o impugnar una pregunta durante el duelo.
- No muestra historial ni progreso individual a lo largo del tiempo.
- No hace matchmaking automático por nivel o racha (el usuario elige el rival manualmente entre los miembros del grupo).
- No muestra resultados preliminares antes de que ambos jugadores terminen.
- No envía notificaciones push.
- No tiene niveles de privacidad de grupo ni permite navegar entre grupos públicos (todos los grupos son cerrados, por invitación).
- No tiene ranking global, ligas, torneos ni sistemas de puntuación tipo ELO.

## Comportamiento esperado
1. El administrador crea un grupo nuevo y la plataforma le da un código/link de invitación para compartir.
2. El administrador carga un archivo con preguntas organizadas por tema.
3. Un miembro recibe el código/link, lo usa para unirse al grupo, y crea su perfil (solo un nombre).
4. Al entrar, el miembro ve los temas disponibles y la lista de otros miembros del grupo.
5. El miembro elige un tema y un rival, y envía el reto. Esto arranca un duelo pendiente para el rival.
6. El rival ve que tiene un duelo pendiente y responde las preguntas cuando tiene tiempo.
7. Cuando ambos jugadores completaron sus respuestas, se muestra el resultado final: quién ganó y el puntaje de cada uno.
8. Si el rival nunca responde, el duelo expira después de un plazo definido y se cancela; quien retó puede iniciar un nuevo duelo con otro rival.

## Errores y seguridad
- **Rival no responde a tiempo**: el duelo expira automáticamente después de un plazo definido y se cancela; no queda pendiente para siempre.
- **Tema sin preguntas suficientes o agotado**: si un miembro ya jugó todas las preguntas disponibles de un tema, se le avisa al administrador que ese tema necesita más contenido; el tema queda marcado como agotado hasta que se cargue más.
- **Archivo de preguntas mal formado al cargar**: si el administrador sube un archivo con errores de formato, recibe un aviso claro de que la carga falló, sin dejar preguntas a medio cargar.
- **Grupo sin suficientes miembros**: si un usuario intenta retar y no hay otros miembros en el grupo, se le indica que necesita invitar a más gente antes de poder jugar.
- **Acceso**: solo puede unirse al grupo y ver su contenido quien tenga el código/link de invitación compartido por el administrador; no hay forma de descubrir o entrar a un grupo sin ese código.

## Éxito
La señal principal de que la Fase 1 funciona es que los duelos iniciados se completen de punta a punta — es decir, que la mayoría de los duelos retados lleguen a mostrar un resultado final, en vez de expirar por falta de respuesta del rival.

## V2 (opcional)
- **Reportar pregunta**: botón para marcar una pregunta como mal formulada, aunque ya haya sido revisada al cargarla.
- **Historial/progreso individual**: ver la evolución propia por tema a lo largo del tiempo.
- **Resultados preliminares post-envío**: ver cómo van los demás participantes, pero solo después de haber enviado las propias respuestas (evita que alguien demore su respuesta para espiar a otros primero).
- **Matchmaking por nivel/racha**: emparejamiento automático por nivel similar, usando datos de partidas jugadas en la Fase 1.
- **Niveles de privacidad de grupo y navegación entre grupos públicos**: permitir que existan grupos abiertos, además de los cerrados por invitación, con un sistema de descubrimiento.
- **Resolución formal de impugnaciones, notificaciones push, ligas/divisiones, sistema ELO, torneos por bracket**: quedan en el radar más lejano, solo si el uso real del producto los justifica.
