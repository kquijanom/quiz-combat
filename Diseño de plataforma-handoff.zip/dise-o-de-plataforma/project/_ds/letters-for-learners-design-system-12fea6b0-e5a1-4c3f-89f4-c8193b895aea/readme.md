# Letters for Learners Design System

A warm, welcoming design system for an educational learning platform with a focus on accessibility, clarity, and engagement.

## Brand Overview

**Letters for Learners** is an educational platform designed to make learning intuitive, approachable, and rewarding. The visual identity combines a warm, optimistic color palette with clean, readable typography to create an inviting learning environment.

### Visual Identity
- **Primary Color**: Gold (#FFB300) — warmth, optimism, achievement
- **Secondary Colors**: Orange, Navy — supporting actions and depth
- **Tone**: Friendly, encouraging, approachable
- **Typography**: Poppins for headings (display, friendly), Inter for body (readable, modern)

## Content Fundamentals

Writing for Letters for Learners emphasizes:
- **Tone**: Encouraging, positive, supportive — never condescending
- **Voice**: First-person inclusive ("Let's learn together") balanced with clear instruction
- **Clarity**: Direct, concise copy that guides users through tasks
- **Emoji**: Used sparingly for emphasis and celebration (achievement badges, progress milestones)
- **Casing**: Sentence case for body copy, Title Case for headings and buttons
- **Language**: "You" focused — "Start your lesson" not "Users start lessons"

Example copy: "You've completed 5 lessons this week! Keep the momentum going."

## Visual Foundations

### Color System
- **Warm primary palette**: Gold family (100–600) creates the primary brand voice
- **Neutral foundation**: Navy for depth and contrast, grays for supporting text and dividers
- **Semantic colors**: Green (success), amber (warning), red (error), blue (info) for actionable states

### Typography
- **Display**: Poppins Bold/SemiBold, 28–48px, friendly and approachable
- **Body**: Inter Regular/Medium, 14–18px, clear and legible at all sizes
- **Line heights**: Tight (1.2) for headings, Normal (1.5) for body, Relaxed (1.75) for longer reads

### Spacing & Layout
- **Scale**: 4px base unit, scaling to 4, 8, 12, 16, 24, 32, 48, 64px
- **Cards**: 12px border radius, subtle shadow (0 4px 6px), padding of 16–32px
- **Gaps**: 16px standard gap between sections, 8px between small elements

### Interactive States
- **Hover**: Box shadow lift (md shadow), slight color shift on buttons
- **Active/Pressed**: Darker color or scale reduction (optional)
- **Focus**: 3px gold outline for accessibility
- **Disabled**: 60% opacity

### Imagery & Backgrounds
- **Images**: Warm-toned, educational, diverse representation
- **Backgrounds**: Clean white, subtle gray accents, occasional full-bleed gold blocks for emphasis
- **Illustrations**: Hand-drawn style, colorful, supporting educational concepts
- **Patterns**: Minimal, subtle textures on dark backgrounds only

### Animations
- **Easing**: ease-in-out for smooth, natural motion
- **Timing**: 150ms (fast), 200ms (base), 300ms (slow)
- **Approach**: Subtle transitions on hover/focus, fade-in for content reveal, no bounces on core UI

### Borders & Shadows
- **Borders**: 1px subtle gray (#D5D5D5) on cards, inputs, dividers
- **Shadows**: Subtle sm (0 1px 2px), md for hover (0 4px 6px), no heavy shadows
- **Radius**: 4px for small elements, 8px standard, 12px for cards, 16px for larger components

## File Structure

```
letters-for-learners-ds/
├── styles.css                 # Global imports
├── tokens/
│   ├── colors.css            # Color palette and semantic colors
│   ├── typography.css        # Font families, sizes, weights
│   └── spacing.css           # Spacing scale, shadows, radii
├── components/
│   ├── Button.jsx            # Primary action component
│   ├── Button.d.ts           # Props interface
│   ├── Button.prompt.md      # Usage guide
│   ├── Card.jsx              # Container component
│   ├── Input.jsx             # Text input field
│   ├── Badge.jsx             # Label/tag component
│   └── showcase.html         # Component gallery
├── cards/
│   ├── colors-primary.html   # Primary color palette
│   ├── colors-neutral.html   # Neutral colors
│   ├── colors-semantic.html  # Status colors
│   ├── type-display.html     # Display & heading type
│   ├── type-body.html        # Body text sizes
│   └── spacing-scale.html    # Spacing scale reference
└── readme.md                  # This file
```

## Components

The design system includes four core components:

- **Button** — Primary, secondary, and ghost variants for actions
- **Card** — Container with border, shadow, and optional hover state
- **Input** — Text input field with focus states
- **Badge** — Inline labels for tags, status, and categories

Each component is available as a React export and can be customized via props.

## Tokens

All values are defined as CSS custom properties in the `tokens/` folder:

- **Colors**: Primary (gold), secondary (orange), neutral (navy, grays), semantic (success, warning, error, info)
- **Typography**: Font families, sizes (XS–XL), weights (regular–bold), line heights
- **Spacing**: Scale from 4px to 64px, plus shadows, border radii, and transitions

Consuming projects import `styles.css` to access all tokens.

## Usage

### In a Design Component (Design System)
```html
<x-import component-from-global-scope="LettersForLearners.Button" hint-size="200x48">
  Get Started
</x-import>
```

### In a Consuming Project
```jsx
import { Button } from '@project/design-system';

export function Hero() {
  return <Button variant="primary">Start Learning</Button>;
}
```

## Extending the System

To add new components:
1. Create `ComponentName.jsx` with a named export
2. Add `ComponentName.d.ts` with the props interface
3. Add `ComponentName.prompt.md` with usage examples
4. Reference in a showcase card or component gallery
5. Run `check_design_system` to validate

## Notes

- **Fonts**: Uses Google Fonts (Poppins, Inter) for easy web access
- **Accessibility**: All components support keyboard navigation and focus states
- **Responsive**: Components scale responsively; adjust font sizes and padding at breakpoints as needed
- **Future Additions**: Planned components include Select, Checkbox, Radio, Tabs, Modal, and Toast

---

**Last Updated**: July 2026  
**Status**: Foundation phase — core tokens and components ready
