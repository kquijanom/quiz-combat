/* @ds-bundle: {"format":4,"namespace":"LettersForLearnersDesignSystem_12fea6","components":[{"name":"Badge","sourcePath":"components/Badge.jsx"},{"name":"Button","sourcePath":"components/Button.jsx"},{"name":"Card","sourcePath":"components/Card.jsx"},{"name":"Input","sourcePath":"components/Input.jsx"}],"sourceHashes":{"components/Badge.jsx":"fe75eb6fa0b8","components/Button.jsx":"c1840382ae83","components/Card.jsx":"255e9740043e","components/Input.jsx":"f785fbd1a9f8"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.LettersForLearnersDesignSystem_12fea6 = window.LettersForLearnersDesignSystem_12fea6 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/Badge.jsx
try { (() => {
/**
 * Badge component for labels and tags
 */
function Badge({
  children,
  variant = 'default',
  size = 'md'
}) {
  const sizeStyles = {
    sm: {
      padding: '4px 8px',
      fontSize: 'var(--type-body-xs)'
    },
    md: {
      padding: '6px 12px',
      fontSize: 'var(--type-body-sm)'
    },
    lg: {
      padding: '8px 16px',
      fontSize: 'var(--type-body-md)'
    }
  };
  const variantStyles = {
    default: {
      backgroundColor: 'var(--gold-100)',
      color: 'var(--text-primary)'
    },
    success: {
      backgroundColor: '#D1F2D1',
      color: '#1B5E20'
    },
    warning: {
      backgroundColor: '#FEF3C7',
      color: '#92400E'
    },
    error: {
      backgroundColor: '#FEE2E2',
      color: '#991B1B'
    }
  };
  return React.createElement('span', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      borderRadius: 'var(--radius-full)',
      fontWeight: 'var(--font-weight-semibold)',
      ...sizeStyles[size],
      ...variantStyles[variant]
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Badge.jsx", error: String((e && e.message) || e) }); }

// components/Button.jsx
try { (() => {
/**
 * Button component with primary, secondary, and ghost variants
 * @startingPoint section="Form Controls" subtitle="Primary, secondary, and ghost variants" viewport="280x120"
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  onClick,
  type = 'button'
}) {
  const baseStyles = {
    fontFamily: 'var(--font-body)',
    fontWeight: 'var(--font-weight-semibold)',
    border: 'none',
    borderRadius: 'var(--radius-md)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'var(--transition-base)',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 'var(--spacing-sm)',
    opacity: disabled ? 0.6 : 1
  };
  const sizeStyles = {
    sm: {
      padding: 'var(--spacing-sm) var(--spacing-md)',
      fontSize: 'var(--type-body-sm)'
    },
    md: {
      padding: 'var(--spacing-md) var(--spacing-lg)',
      fontSize: 'var(--type-body-md)'
    },
    lg: {
      padding: 'var(--spacing-lg) var(--spacing-xl)',
      fontSize: 'var(--type-body-lg)'
    }
  };
  const variantStyles = {
    primary: {
      backgroundColor: 'var(--interactive-primary)',
      color: 'var(--text-on-dark)'
    },
    secondary: {
      backgroundColor: 'var(--interactive-secondary)',
      color: 'var(--text-on-dark)'
    },
    ghost: {
      backgroundColor: 'transparent',
      color: 'var(--interactive-primary)',
      border: '2px solid var(--interactive-primary)'
    }
  };
  return React.createElement('button', {
    type,
    onClick,
    disabled,
    style: {
      ...baseStyles,
      ...sizeStyles[size],
      ...variantStyles[variant]
    }
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Button.jsx", error: String((e && e.message) || e) }); }

// components/Card.jsx
try { (() => {
/**
 * Card component for content containers
 */
function Card({
  children,
  padding = 'lg',
  hoverable = false,
  onClick
}) {
  const paddingMap = {
    sm: 'var(--spacing-lg)',
    md: 'var(--spacing-xl)',
    lg: 'var(--spacing-2xl)'
  };
  return React.createElement('div', {
    onClick,
    style: {
      backgroundColor: 'var(--surface-default)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      padding: paddingMap[padding],
      boxShadow: 'var(--shadow-sm)',
      transition: 'var(--transition-base)',
      cursor: hoverable ? 'pointer' : 'default'
    },
    onMouseEnter: hoverable ? e => {
      e.currentTarget.style.boxShadow = 'var(--shadow-md)';
    } : null,
    onMouseLeave: hoverable ? e => {
      e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
    } : null
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Card.jsx", error: String((e && e.message) || e) }); }

// components/Input.jsx
try { (() => {
/**
 * Input component for text fields
 */
function Input({
  placeholder = '',
  value = '',
  onChange,
  disabled = false,
  type = 'text'
}) {
  return React.createElement('input', {
    type,
    placeholder,
    value,
    onChange: e => onChange?.(e.target.value),
    disabled,
    style: {
      width: '100%',
      padding: 'var(--spacing-md) var(--spacing-lg)',
      fontSize: 'var(--type-body-md)',
      fontFamily: 'var(--font-body)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-md)',
      transition: 'var(--transition-base)',
      boxSizing: 'border-box',
      backgroundColor: 'var(--surface-default)',
      color: 'var(--text-primary)'
    },
    onFocus: e => {
      e.target.style.borderColor = 'var(--interactive-primary)';
      e.target.style.boxShadow = '0 0 0 3px rgba(255, 179, 0, 0.1)';
    },
    onBlur: e => {
      e.target.style.borderColor = 'var(--border-default)';
      e.target.style.boxShadow = 'none';
    }
  });
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Input.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Input = __ds_scope.Input;

})();
